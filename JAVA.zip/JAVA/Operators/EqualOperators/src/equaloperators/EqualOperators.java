
package equaloperators;

/**
 *
 * @author Anzuruni
 */
import java.util.Scanner;

public class EqualOperators {

   
    public static void main(String[] args) {
Scanner Obbj=new Scanner(System.in);
int number;
System.out.print("Enter Number");
number=Obbj.nextInt();
if(number==10){
    System.out.println("True");
}
else if(number!=10){
    System.out.println("False");
}
  
    }
}
