
package findtwonumbersequal;

/**
 *
 * @author : James Anzuruni
 */
public class FindTwoNumbersEqual {

    public static void main(String[] args) {
//I declared the Variable a,b,and C as String data type. 
//because the interger is not  dereferenced in java.      
        String a="4"; 
        String b="4";
        String c="10";
        System.out.println(a.equals(b));
        System.out.println(a.equals(c));
    }
    
}
