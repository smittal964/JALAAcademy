
package incrementdecrement;

/**
 *
 * @author James Anzuruni
 */
public class IncrementDecrement {

    public static void main(String[] args) {
        int age=20;
       age++;
    System.out.println(age);
            
    int number=20;
    number--;
    System.out.println(number);
        
}     
        
}   
    

