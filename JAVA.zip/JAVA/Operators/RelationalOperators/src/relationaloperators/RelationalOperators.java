
package relationaloperators;

/**
 *
 * @author:James Anzuruni
 */
public class RelationalOperators {

    
    public static void main(String[] args) {
       int age=10;
       System.out.println(age== 10);
       System.out.println(age!= 10);
       System.out.println(age<10);
       System.out.println(age>10);
       System.out.println(age<= 10);
       System.out.println(age>= 10);
      
    }
    
}
