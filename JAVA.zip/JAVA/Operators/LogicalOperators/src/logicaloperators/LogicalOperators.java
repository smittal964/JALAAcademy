
package logicaloperators;

/**
 *
 * @author:James Anzuruni
 */
public class LogicalOperators {

    public static void main(String[] args) {
     boolean a= true || true;
     System.out.println(a);
     
    boolean b= false && true;
    System.out.println(b);
    
     boolean c= !true;
     System.out.println(c);
     }
        
    }
                
               
       
    

