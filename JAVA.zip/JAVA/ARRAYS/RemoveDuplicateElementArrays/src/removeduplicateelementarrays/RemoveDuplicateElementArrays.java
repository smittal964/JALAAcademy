
package removeduplicateelementarrays;

/**
 *
 * @author Anzuruni
 */
import java.util.*;
import java.util.stream.Collectors;
public class RemoveDuplicateElementArrays {
      static int[] removeDuplicates(int[] array)
    {
        List<Integer> list = new ArrayList<Integer>();
        for(int i : array){
            list.add(i);
        }
        List<Integer> withoutDuplicates = list.stream().distinct().collect(Collectors.toList());
        int[] myArray = new int[withoutDuplicates.size()];
        for(int i = 0;i < myArray.length;i++)
          myArray[i] = withoutDuplicates.get(i);
        return myArray;
    }

   
    public static void main(String[] args) {
         int[] array = { 1, 3,3, 4, 5, 1, 3, 4, 5, 4, 2,2, 6, 5,10,10, 7,7};
        int length = array.length;
        System.out.println("Array Before Removing Duplicates:");
        for (int i=0; i<length; i++)
           System.out.print(array[i]+" ");
        array = removeDuplicates(array);
        int length2 = array.length;
        System.out.println("\nArray After Removing Duplicates:");
        for (int i=0; i<length2; i++)
           System.out.print(array[i]+" ");
        
    }
    
}
