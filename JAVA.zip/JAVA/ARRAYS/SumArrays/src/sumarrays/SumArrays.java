
package sumarrays;

/**
 *
 * @author:James Anzuruni
 */
public class SumArrays {

   
    public static void main(String[] args) {
       // Write a function to add integer values of an array
         int[] array = {10, 20, 30, 40, 50, 10};
          int sum = 0;
          
             //Advanced for loop
      for( int num : array) {
          sum = sum+num;
      }
      System.out.println("Sum of array elements is:"+sum);
    }
    
}
