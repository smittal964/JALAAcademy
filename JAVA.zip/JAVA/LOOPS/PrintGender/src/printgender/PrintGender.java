
package printgender;

/**
 *
 * @author: Anzuruni
 */
import java.util.Scanner;
public class PrintGender {

  
    public static void main(String[] args) {
        Scanner Obbj=new Scanner(System.in);
        char gender;
        
        System.out.println("Select Your Gender (M/m or F/f)");
        gender=Obbj.next().charAt(0);
            switch(gender)
    {
        case 'M':
        case 'm':
            System.out.println("Male.");
            break;
        case 'F':
        case 'f':
            System.out.println("Female.");
            break;
        default:
            System.out.println("Unspecified Gender.");
    }
 
        
       
    }
    
}
