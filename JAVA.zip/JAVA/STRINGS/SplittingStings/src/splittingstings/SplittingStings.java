
package splittingstings;


public class SplittingStings {

   
    public static void main(String[] args) {
         String str = "james@Arel@Welcome";
        String[] arrOfStr = str.split("@");
  
        for (String a : arrOfStr)
            System.out.println(a);
    }
    
}
