
package exactsubstring;


public class ExactSubString {

   
    public static void main(String[] args) {
 String s="LambetAnzuruni";    
 System.out.println("Original String: " + s);  
 System.out.println("Substring starting from index 6: " +s.substring(6));//Anzuruni    
 System.out.println("Substring starting from index 0 to 6: "+s.substring(0,6)); //James  
    }
    
}
