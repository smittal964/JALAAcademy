
package stringlength;


public class StringLength {

    
    public static void main(String[] args) {
       String domainName = "www.jamesanzuruni44.com";
        int length = domainName.length();
        System.out.println("String.length() is: " + length);

        String Myname = "James"; 
        length = Myname.length();
        System.out.println("String.length() of " + Myname + " is: " + Myname.length());
        System.out.println("String Count point() of " + Myname + " is: " + Myname.codePointCount(0, Myname.length()));
    }
    
}
