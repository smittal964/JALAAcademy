
package replacingcharacters;


public class ReplacingCharacters {

   
    public static void main(String[] args) {
 String s1="Arel is a very good humanitarian forum";  
String replaceString=s1.replace('a','e');//replaces all occurrences of 'a' to 'e'  
System.out.println(replaceString);  
    }
    
}
