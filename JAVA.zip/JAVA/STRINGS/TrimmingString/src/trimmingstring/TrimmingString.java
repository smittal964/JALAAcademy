
package trimmingstring;

public class TrimmingString {

 
    public static void main(String[] args) {
        //initialize string
        String str = "  \t\n\n\tHello World!\n Welcome to www.Arel.org\n\n\t";
         
        //trim string
        String result = str.trim();
         
        System.out.println("\""+result+"\"");
    }
    
}
