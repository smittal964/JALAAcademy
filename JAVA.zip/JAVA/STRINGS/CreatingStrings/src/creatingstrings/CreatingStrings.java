
package creatingstrings;

/**
 *
 * @author: Anzuruni
 */
// Java code to illustrate String
import java.io.*;
import java.lang.*;
public class CreatingStrings {

   
    public static void main(String[] args) {
         // Declare String without using new operator
        String s = "Anzuruni44";
 
        // Prints the String.
        System.out.println("String s = " + s);
 
        // Declare String using new operator
        String s1 = new String("Anzuruni44");
 
        // Prints the String.
        System.out.println("String s1 = " + s1);
        
    }
    
}
