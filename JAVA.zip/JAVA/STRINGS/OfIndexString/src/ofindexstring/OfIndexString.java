
package ofindexstring;


public class OfIndexString {

  
    public static void main(String[] args) {
         String str = "hello world";
        
        int index = str.indexOf("world");        
        System.out.println(index);
        
        index = str.indexOf("hi");
        System.out.println(index);  
    }
    
}
