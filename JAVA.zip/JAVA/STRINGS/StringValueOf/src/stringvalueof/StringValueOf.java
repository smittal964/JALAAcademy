
package stringvalueof;


public class StringValueOf {

    
    public static void main(String[] args) {
int value=30;  
String s1=String.valueOf(value);  
System.out.println(s1+10);//concatenating string with 10  
    }
    
}
