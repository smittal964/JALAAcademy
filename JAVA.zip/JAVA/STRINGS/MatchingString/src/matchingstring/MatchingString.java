
package matchingstring;

import java.util.Arrays;
import java.util.List;
public class MatchingString {

 
    public static void main(String[] args) {
        
        List<String> strList = Arrays.asList("Chicago","Nairobi", "Lubumbashi", "London", "Lisbon", "Mumbai");
    for(String str : strList) {
      if(str.matches("L.*"))
        System.out.println(str);            
        
    }
    
}
}
